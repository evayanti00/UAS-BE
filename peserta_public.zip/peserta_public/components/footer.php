<footer class="bg-dark text-white text-center py-3 mt-5">
    <p class="mb-0">
        © 2026 Sistem Pendaftaran Event Kampus
    </p>
</footer>