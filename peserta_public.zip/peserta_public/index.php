<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Event Kampus</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include 'components/navbar.php'; ?>

<!-- Hero Section -->
<section class="hero text-center">
    <div class="container">
        <h1 class="fw-bold">Sistem Pendaftaran Event Kampus</h1>
        <p class="lead">
            Temukan seminar, workshop, Lomba dan kegiatan kampus terbaru.
        </p>
    </div>
</section>

<!-- Event List -->
<section class="container my-5">
    <h2 class="text-center mb-4">Daftar Event</h2>

    <div class="row">

        <div class="col-md-4 mb-4">
            <div class="card shadow">
                <img src="assets/images/himatography_1.jpeg"
                class="card-img-top event-img"
                alt="Lomba Foto Nasional">            
                   <div class="card-body">
                    <h5 class="card-title">Lomba Foto Nasional 2026</h5>
                    <p>📅 Pendaftaran : 12 April - 15 Juli 2026</p>
                    <p>💰 Biaya : Rp50.000</p>

                    <a href="detail_event.php?id=1" class="btn btn-primary">
                        Lihat Detail
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card shadow">
                <img src="assets/images/geteksi_1.jpeg"
                class="card-img-top event-img"
                alt="GETEKSI VOL. 3">            
                <div class="card-body">
                    <h5 class="card-title">GETEKSI VOL. 3</h5>
                    <p>📅 07 Juni 2026</p>
                    <p>📍 Aula ITB STIKOM BALI & ZOOM MEETING</p>

                    <a href="detail_event.php?id=2" class="btn btn-primary">
                        Lihat Detail
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'components/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>